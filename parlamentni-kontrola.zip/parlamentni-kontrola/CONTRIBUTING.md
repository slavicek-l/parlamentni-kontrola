# Contrib

- Vytvářej feature větve a PR
- Piš testy (pytest, httpx, cypress)
- Respektuj lint (ruff, mypy, prettier)
