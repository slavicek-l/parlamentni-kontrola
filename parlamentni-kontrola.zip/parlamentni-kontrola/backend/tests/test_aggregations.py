def test_dummy_agg():
    assert 1+1==2
