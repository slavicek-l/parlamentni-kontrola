export function TableSkeleton(){
  return <div>Načítání tabulky...</div>;
}

export function ChartSkeleton(){
  return <div>Načítání grafu...</div>;
}
