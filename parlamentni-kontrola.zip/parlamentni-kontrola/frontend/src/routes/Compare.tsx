export default function Compare(){
  return <div>Porovnání poslanců</div>;
}
