# Infrastructure

Placeholder pro budoucí Terraform/Kubernetes konfigurace pro produkční nasazení.
